
/**
 * @author Sara Arias Hernández
 */

import { getData } from "../helpers/getData"

const api = import.meta.env.VITE_URL_API
const port = import.meta.env.VITE_PORT

export class Destination{
    #name
    #date
    #tripCost

    constructor(name, date, budget){
        this.#name=name
        this.#date=date
        this.#tripCost=budget
    }

    async updateTripCost(newTripCost, id){
        try {
            let newId=0;
            const data = await getData(`${api}${port}/destinations`);
                    
            data.map((d, i)=>{
                if(i==id){
                    newId=d.id;
                }
            })

            this.#tripCost=newTripCost;
            const response = await fetch(`${api}${port}/destinations/${newId}`, {
                method: 'PATCH',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  budget: newTripCost
                })
            });
            if(!response.ok){
                throw new Error("Error al cambiar el dato");
            }
        } catch (error) {
            console.error("Error en updateTripCost: ", error)
        }
  
    }

    get name(){
        return this.#name
    }

    get date(){
        return this.#date
    }

    get tripCost(){
        return this.#tripCost
    }
}
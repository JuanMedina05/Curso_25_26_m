
/**
 * @author Sara Arias Hernández
 */

import { getData } from "../helpers/getData";
import { Destination } from "./Destination";

export class TravelPlanner{
    #destinations
    #apiURL

    constructor(url){
        this.#destinations = [];
        this.#apiURL=url;
    }

    async fetchDestinations(){
        try {
            const data = await getData(this.#apiURL);
            this.#destinations= data.map(({ name, date, budget })=>{
                const destino = new Destination(name, date,budget);
    
                return destino;
            })
        } catch (error) {
            console.error("Error en fetchDestinatios: ", error)
        }
    }

    async addDestination(destination){
        try {
            const data = await getData(this.#apiURL);
            const destino = {
                id: String(data.length+1),
                name: destination.name,
                date: destination.date,
                budget: destination.tripCost
            }
            const response = await fetch(this.#apiURL, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify(destino),
              })
            if(!response.ok){
                throw new Error("Error al añadir el destino");
            }
        } catch (error) {
            console.error("Error en addDestination: ", error)
        }
    }

    async deleteDestination(idDestination){
        try { 
            let newId=0;
            const data = await getData(this.#apiURL);
            
            data.map((d, i)=>{
                if(Number(i)==idDestination){
                    newId=d.id;
                    console.log(d.id);
                }
            })
            const response = await fetch(`${this.#apiURL}/${newId}`,{
                method: 'DELETE',
            })
            if(!response.ok){
                throw new Error("Error al borrar el destino");
            } 
        } catch (error) {
            console.error("Error en deleteDestiancion: ", error)
        }
    }

    async getDestinations(){
        try {
            await this.fetchDestinations();
            return this.#destinations;
        } catch (error) {
            console.error("Error en getDestionations");
        }
    }
}
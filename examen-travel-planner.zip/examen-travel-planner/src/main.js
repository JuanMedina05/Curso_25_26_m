
/**
 * @author Sara Arias Hernández
*/

import { Destination } from "./classes/Destination";
import { TravelPlanner } from "./classes/TravelPlanner";

async function init() {
    const api = import.meta.env.VITE_URL_API
    const port = import.meta.env.VITE_PORT
    
    const travelPlanner = new TravelPlanner(`${api}${port}/destinations`);
    
    const app = document.getElementById("app");
    const fecha = new Date();
    const obj={
        name:"Sara",
        date: `${fecha.getFullYear()}-${fecha.getMonth()}-${fecha.getDay()}`
    }
    
    const createNavBar = async () =>{
        const nav = document.createElement("nav");
    
        if(!localStorage.getItem("contador")){
            localStorage.removeItem("contador");
        }
        
        let contador=0;
        const totalDestino = await travelPlanner.getDestinations();
        
        if(totalDestino.length>0){
            contador=totalDestino.length;
        }
        localStorage.setItem("contador", contador);
    
        const button = document.createElement("button");
        button.id="addDestination"
        button.textContent="Agregar Destino";
    
        const total = document.createElement("p");
        total.textContent=`Destinos totales= ${localStorage.getItem("contador")}`
        nav.append(button, total);
       
        button.addEventListener("click", async()=>{ 
            const form = await createDestinationForm();
            if(form.classList.contains("visible")){
                nav.append(form);
            }
        });
    
        return nav;
    }
    
    const createFooter = async(obj) =>{
        const footer = document.createElement("footer");
        footer.innerHTML=`
            <p>${obj.name}</p>
            <p>${obj.date}</p>
        `;
        return footer;
    }
    
    const createDestinationForm = async () =>{
        if(!document.getElementById("form")){
            const form = document.createElement("form");
            form.id="form";
            form.classList.add("visible");
        
            const inputNombre = document.createElement("input");
            inputNombre.id="inputNombre"
            inputNombre.type="text"
            inputNombre.placeholder="Nombre del destino" 
            inputNombre.required=true
        
            const inputDate = document.createElement("input");
            inputDate.id="inputDate"
            inputDate.type="date"
            inputDate.required=true
        
            const inputPresupuesto = document.createElement("input");
            inputPresupuesto.id="inputPresupuesto"
            inputPresupuesto.type="number"
            inputPresupuesto.placeholder="Presupuesto"
            inputPresupuesto.required=true
        
            const button = document.createElement("button");
            button.id="btn-form"
            button.textContent="Añadir"
        
            form.append(inputNombre, inputDate, inputPresupuesto, button);
        
            
            button.addEventListener("click", () => {
                try {
                    const name = document.getElementById("inputNombre").value.trim();
                    const date = document.getElementById("inputDate").value.trim();
                    const budget = document.getElementById("inputPresupuesto").value.trim();
                    guardar(name, date, budget);     
                } catch (error) {
                    console.error(error)
                }
            });
    
            return form;
        }else{
            document.getElementById("form").remove("visible"); 
        }
    }
    
    const guardar = (name, date, budget) =>{
        try {
            travelPlanner.addDestination(new Destination(name, date, Number(budget)));
            travelPlanner.fetchDestinations();
        } catch (error) {
            console.error(error);
        }
       
    }
    
    const renderDestinationList = async() =>{
        const div = document.createElement("div");
        div.id="cards"
        const data = await travelPlanner.getDestinations();
        div.innerHTML=data.map((d,i)=>{
            return `
                <div class="card">
                    <h2>Destino: ${d.name}</h2>
                    <p>Fecha: ${d.date}</p>
                    <p>Precio: ${d.tripCost}</p>
                    <button class="btn-del" data-del=${i}>Eliminar</button>
                    <button class="btn-edit" data-edit="${d.name},${d.date},${d.tripCost}"  data-id=${i}>Editar presupuesto</button>
                </div>
            `;
        })
    
        document.addEventListener("click", async(event)=>{
            const del = event.target.dataset.del;
            const edit = event.target.dataset.edit;
            const id = event.target.dataset.id;
            if(del) {
                await travelPlanner.deleteDestination(del)
                location.reload();
            };
      
            if(edit && id){
                const n = prompt("Introduce el nuevo precio:");
                const datos = edit.split(",");
    
                const destino = new Destination(datos[0], datos[1], n)
                await destino.updateTripCost(n, id);
                location.reload();
            }
        })
        return div;
    }
    
    const nav = await createNavBar();
    const destinos = await renderDestinationList();
    const footer = await createFooter(obj);
    app.append(nav, destinos, footer)
}
init();



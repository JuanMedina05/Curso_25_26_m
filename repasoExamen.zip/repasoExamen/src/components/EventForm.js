import { Event } from "../clases/Event";
import { EventManager } from "../clases/EventManager";

export const EventForm = () =>{
  if(!document.getElementById("form")){
    const nav = document.getElementById("nav");

    const url = import.meta.env.VITE_URL_API;
    const puerto = import.meta.env.VITE_PORT;
  
    const eventManager = new EventManager(`${url}${puerto}/events/`); 

    const div = document.createElement("div");
    div.classList.add("div-form", "invisible");

    const titulo = document.createElement("h2");
    titulo.textContent="FORMULARIO eventos"

    const form = document.createElement("form");
    form.id="form";
    form.innerHTML=`
      <input type="text" id="title" placeholder="Titulo">
      <label for="date">Fecha</label>
      <input type="date" id="date">
      <input type="text" id="organizador" placeholder="Organizador">
      <input type="submit" value="Guardar" id="btn-enviar">
    `;

    div.append(titulo, form);
 
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const title = document.getElementById("title").value.trim();
        const date = document.getElementById("date").value.trim();
        const organizador = document.getElementById("organizador").value.trim();
        const event = new Event(title, date, organizador);

        try {
          await eventManager.addEvent(event);
          form.reset();
        } catch (error) {
          console.error("error: ", error);
        }
    })  

    nav.append(div);
  }else{

  }
   
}
import { EventManager } from "../clases/EventManager";

export const EventList = async () => {
    const puerto = import.meta.env.VITE_PORT
    const url = import.meta.env.VITE_URL_API
    
    const eventManager = new EventManager(`${url}${puerto}/events`);
    const events = await eventManager.getEvents();

    const divEvents = document.createElement("div");
    divEvents.id="idList"
    divEvents.classList.add("cards");

    divEvents.innerHTML = events.map((e, i) => {
        let color = "#646cff00"
        let texto = "Marcar como importante"
        let classs = "importante"

        if (localStorage.getItem("importantEvent") && JSON.parse(localStorage.getItem("importantEvent")).some(l => l === i)) {
            color = "orange";
            texto = "quitar como importante"
            classs = "notImportante"
        }
        
        return `
            <div class="card" data-id=${i} style="background-color:${color}">
                <h2>${e.title}</h2>
                <p>${e.date}</p>
                <p>${e.organizer}</p>
                <button type="submit" data-imp=${i} class="${classs}">${texto}</button><br><br>
                <button type="submit" data-del=${i} id="borrar">Borrar</button>
            </div>
        `;
    }).join("");
    
    document.addEventListener("click", (event) => {
        const imp = event.target.dataset.imp;
        const del = event.target.dataset.del;

        if(imp) {
            eventManager.markAsImportant(Number(imp))
        };
        if (del) eventManager.deleteEvent(Number(del));
        
    });
 

    return divEvents;
}


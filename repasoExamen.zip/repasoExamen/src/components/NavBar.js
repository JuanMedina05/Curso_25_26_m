import { EventForm } from "./EventForm";

export const NavBar = (obj) => {
    const navBar = document.createElement("nav");
    navBar.id="nav";
    const div = document.createElement("div");
    div.id="div-nav"

    const titulo = document.createElement("h2");
    titulo.textContent="EXAMEN JAVASCRIPT 2024"

    const nombreP = document.createElement("p");
    nombreP.textContent=obj.nombre;

    const fechaP = document.createElement("p");
    fechaP.textContent=obj.fecha;

    const button = document.createElement("button");
    button.id="btn-nav";
    button.textContent="MOSTRAR FORMULARIO";

    div.append(nombreP, fechaP, button);
    navBar.append(titulo, div);

    button.addEventListener("click", () =>{
    EventForm();
    const form = document.querySelector(".div-form");
        if (form.classList.contains("visible")) {
            form.classList.remove("visible");
            form.classList.add("invisible");
        } else if (form.classList.contains("invisible")) {
            form.classList.remove("invisible");
            form.classList.add("visible");
        }
    });

    return navBar;
}
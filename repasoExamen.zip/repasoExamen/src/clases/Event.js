export class Event{
    #title;
    #date;
    #organizer;

    constructor(title, date, organizer){
        this.#title=title;
        this.#date=date;
        this.#organizer=organizer;
    }

    updateDate(newDate){
        this.#date=newDate;
    }

    get title(){
        return this.#title;
    }

    get date(){
        return this.#date;
    }

    get organizer(){
        return this.#organizer;
    }
}
import { Event } from "./Event";
/**
 * @author Sara Arias Hernández
 */
export class EventManager{
    #events
    #apiUrl

    constructor(api){
        this.#events=[]
        this.#apiUrl=api
    }

    async fetchEvents(){
        try {
            const response = await fetch(this.#apiUrl);
            if(!response.ok){
                throw new Error("Error al obtener los eventos");
            }
            const data = await response.json();
            this.#events=data.map(({ title, date, organizer }) => new Event(title, date, organizer));
        } catch (error) {
            console.error("Error en fetchEvents: ", error)
        }
    }

    async addEvent(event){
         try {  
            const response = await fetch(this.#apiUrl);
            if(!response.ok){
                throw new Error("Error al obtener los eventos");
            }
            const data = await response.json();
            if(!data.some(d=>d.title==event.title && d.date==event.date && d.organizer == event.organizer)){
                const evento = {
                    title:event.title,
                    date:event.date,
                    organizer:event.organizer
                } 

                const response = await fetch(this.#apiUrl,{
                    method: 'POST',
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(evento)
                });
                if(!response.ok){
                    throw new Error("Error al insertar el event");
                }
                this.#events.push(event);
            }

        } catch (error) {
            console.error("Error en addEvent: ", error)
        }
    }

    async deleteEvent(idEvent){
        try {
            const response1 = await fetch(this.#apiUrl);
            if(!response1.ok){
                throw new Error("Error al obtener los eventos");
            }
            const data = await response1.json();
            let id=0;
            data.map((e,i)=>{
                if(i==idEvent){
                    id=e.id;
                }
            })
            const response = await fetch((`${this.#apiUrl}/${id}`),{
                method: 'DELETE'
            });
            if(!response.ok){
                throw new Error("Error al insertar el event");
            }
            this.#events.splice(idEvent, 1);
        } catch (error) {
            console.error("Error en idEvent: ", error);
        }
    }

    async markAsImportant(eventId){
        const e = document.querySelector(`[data-imp="${eventId}"]`)
        let ids = localStorage.hasOwnProperty("importantEvent") ? JSON.parse(localStorage.getItem("importantEvent")) : [];
        if(e.classList.contains("importante")){
            if (!ids.includes(eventId)) {
                ids.push(eventId);
            }
        }else{
            const i = ids.findIndex(i=>Number(i)==Number(eventId));
            ids.splice(i, 1);
        }
        localStorage.setItem("importantEvent", JSON.stringify(ids));   
    }

    getImportantEvents(){
        return localStorage.hasOwnProperty("importantEvent") ? JSON.parse(localStorage.getItem("importantEvent")) : [];
    }

    async getEvents(){
        try {
            await this.fetchEvents();
            return this.#events;
        } catch (error) {
            console.error(error)
        }
    }

}
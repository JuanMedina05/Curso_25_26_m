import { NavBar } from "./components/NavBar";
import { Event } from "./clases/Event";
import { EventManager } from "./clases/EventManager";
import { EventList } from "./components/EventList";

const obj = {
  nombre:"sara",
  fecha:"08/08"
}

const app =document.getElementById("app");
const nav = NavBar(obj);
try {
  const list = await EventList();
  app.append(nav, list);
} catch (error) {
  console.error("Error al cargar los eventos")
}

